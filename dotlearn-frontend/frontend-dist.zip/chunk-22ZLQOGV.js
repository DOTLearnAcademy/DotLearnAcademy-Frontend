import{b as qe}from"./chunk-6MQ5H6K4.js";import{a as Ze,b as Ke,c as Je,d as We,e as Ye,f as et,g as tt,h as nt,i as at,j as ct,k as it}from"./chunk-NBHZYC3T.js";import{a as Be,b as He}from"./chunk-MNW2PYRS.js";import"./chunk-7BB22KQG.js";import{a as Ve,b as Ne,c as $e}from"./chunk-AEJHKCAX.js";import"./chunk-TAALJSIT.js";import{a as z,b as Ge}from"./chunk-ZUHJUQRL.js";import{b as Qe}from"./chunk-2NQ4KA57.js";import{D as De,E as Oe,G as ze,J as Le,N as Fe,O as Re,a as Ie,c as Ee,g as Se,h as Te,j as we,k as Ae,n as Ue,q as H,t as Pe}from"./chunk-LF37PVZA.js";import{Aa as Xe,H as ue,R as _e,Z as xe,ba as fe,c as he,da as ge,e as P,ea as ve,ga as ye,ia as Ce,k as be,ka as Me,p as D,v as pe,xa as O,y as ke,ya as je,za as g}from"./chunk-CDXJI4WC.js";import{$b as ae,Aa as N,Ba as Y,Bb as p,Ea as ee,J as X,Ja as te,Kb as $,Kc as de,Ma as ne,N as Q,Qb as d,Rb as c,Rc as se,Sb as o,Tb as b,Uc as f,Vc as le,Xb as v,Yb as y,_b as w,cc as x,ec as l,fc as A,ga as Z,gc as U,hb as m,ia as I,ic as ce,jc as q,ka as K,kc as B,ma as u,oc as ie,qb as C,qc as M,rc as oe,sa as E,sc as r,ta as S,tc as k,ua as J,uc as re,va as W,wb as _,xb as T,xc as me}from"./chunk-GZG6EVBY.js";var dt=["mat-internal-form-field",""],st=["*"],ot=(()=>{class t{labelPosition="after";static \u0275fac=function(n){return new(n||t)};static \u0275cmp=_({type:t,selectors:[["div","mat-internal-form-field",""]],hostAttrs:[1,"mdc-form-field","mat-internal-form-field"],hostVars:2,hostBindings:function(n,a){n&2&&M("mdc-form-field--align-end",a.labelPosition==="before")},inputs:{labelPosition:"labelPosition"},attrs:dt,ngContentSelectors:st,decls:1,vars:0,template:function(n,a){n&1&&(A(),U(0))},styles:[`.mat-internal-form-field {
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  display: inline-flex;
  align-items: center;
  vertical-align: middle;
}
.mat-internal-form-field > label {
  margin-left: 0;
  margin-right: auto;
  padding-left: 4px;
  padding-right: 0;
  order: 0;
}
[dir=rtl] .mat-internal-form-field > label {
  margin-left: auto;
  margin-right: 0;
  padding-left: 0;
  padding-right: 4px;
}

.mdc-form-field--align-end > label {
  margin-left: auto;
  margin-right: 0;
  padding-left: 0;
  padding-right: 4px;
  order: -1;
}
[dir=rtl] .mdc-form-field--align-end .mdc-form-field--align-end label {
  margin-left: 0;
  margin-right: auto;
  padding-left: 4px;
  padding-right: 0;
}
`],encapsulation:2,changeDetection:0})}return t})();var lt=["input"],ht=["label"],bt=["*"],j={color:"accent",clickAction:"check-indeterminate",disabledInteractive:!1},pt=new K("mat-checkbox-default-options",{providedIn:"root",factory:()=>j}),h=(function(t){return t[t.Init=0]="Init",t[t.Checked=1]="Checked",t[t.Unchecked=2]="Unchecked",t[t.Indeterminate=3]="Indeterminate",t})(h||{}),G=class{source;checked},kt=(()=>{class t{_elementRef=u(ne);_changeDetectorRef=u(se);_ngZone=u(Y);_animationsDisabled=xe();_options=u(pt,{optional:!0});focus(){this._inputElement.nativeElement.focus()}_createChangeEvent(e){let n=new G;return n.source=this,n.checked=e,n}_getAnimationTargetElement(){return this._inputElement?.nativeElement}_animationClasses={uncheckedToChecked:"mdc-checkbox--anim-unchecked-checked",uncheckedToIndeterminate:"mdc-checkbox--anim-unchecked-indeterminate",checkedToUnchecked:"mdc-checkbox--anim-checked-unchecked",checkedToIndeterminate:"mdc-checkbox--anim-checked-indeterminate",indeterminateToChecked:"mdc-checkbox--anim-indeterminate-checked",indeterminateToUnchecked:"mdc-checkbox--anim-indeterminate-unchecked"};ariaLabel="";ariaLabelledby=null;ariaDescribedby;ariaExpanded;ariaControls;ariaOwns;_uniqueId;id;get inputId(){return`${this.id||this._uniqueId}-input`}required=!1;labelPosition="after";name=null;change=new N;indeterminateChange=new N;value;disableRipple=!1;_inputElement;_labelElement;tabIndex;color;disabledInteractive;_onTouched=()=>{};_currentAnimationClass="";_currentCheckState=h.Init;_controlValueAccessorChangeFn=()=>{};_validatorChangeFn=()=>{};constructor(){u(ue).load(ge);let e=u(new de("tabindex"),{optional:!0});this._options=this._options||j,this.color=this._options.color||j.color,this.tabIndex=e==null?0:parseInt(e)||0,this.id=this._uniqueId=u(_e).getId("mat-mdc-checkbox-"),this.disabledInteractive=this._options?.disabledInteractive??!1}ngOnChanges(e){e.required&&this._validatorChangeFn()}ngAfterViewInit(){this._syncIndeterminate(this.indeterminate)}get checked(){return this._checked}set checked(e){e!=this.checked&&(this._checked=e,this._changeDetectorRef.markForCheck())}_checked=!1;get disabled(){return this._disabled}set disabled(e){e!==this.disabled&&(this._disabled=e,this._changeDetectorRef.markForCheck())}_disabled=!1;get indeterminate(){return this._indeterminate()}set indeterminate(e){let n=e!=this._indeterminate();this._indeterminate.set(e),n&&(e?this._transitionCheckState(h.Indeterminate):this._transitionCheckState(this.checked?h.Checked:h.Unchecked),this.indeterminateChange.emit(e)),this._syncIndeterminate(e)}_indeterminate=ee(!1);_isRippleDisabled(){return this.disableRipple||this.disabled}_onLabelTextChange(){this._changeDetectorRef.detectChanges()}writeValue(e){this.checked=!!e}registerOnChange(e){this._controlValueAccessorChangeFn=e}registerOnTouched(e){this._onTouched=e}setDisabledState(e){this.disabled=e}validate(e){return this.required&&e.value!==!0?{required:!0}:null}registerOnValidatorChange(e){this._validatorChangeFn=e}_transitionCheckState(e){let n=this._currentCheckState,a=this._getAnimationTargetElement();if(!(n===e||!a)&&(this._currentAnimationClass&&a.classList.remove(this._currentAnimationClass),this._currentAnimationClass=this._getAnimationClassForCheckStateTransition(n,e),this._currentCheckState=e,this._currentAnimationClass.length>0)){a.classList.add(this._currentAnimationClass);let s=this._currentAnimationClass;this._ngZone.runOutsideAngular(()=>{setTimeout(()=>{a.classList.remove(s)},1e3)})}}_emitChangeEvent(){this._controlValueAccessorChangeFn(this.checked),this.change.emit(this._createChangeEvent(this.checked)),this._inputElement&&(this._inputElement.nativeElement.checked=this.checked)}toggle(){this.checked=!this.checked,this._controlValueAccessorChangeFn(this.checked)}_handleInputClick(){let e=this._options?.clickAction;!this.disabled&&e!=="noop"?(this.indeterminate&&e!=="check"&&Promise.resolve().then(()=>{this._indeterminate.set(!1),this.indeterminateChange.emit(!1)}),this._checked=!this._checked,this._transitionCheckState(this._checked?h.Checked:h.Unchecked),this._emitChangeEvent()):(this.disabled&&this.disabledInteractive||!this.disabled&&e==="noop")&&(this._inputElement.nativeElement.checked=this.checked,this._inputElement.nativeElement.indeterminate=this.indeterminate)}_onInteractionEvent(e){e.stopPropagation()}_onBlur(){Promise.resolve().then(()=>{this._onTouched(),this._changeDetectorRef.markForCheck()})}_getAnimationClassForCheckStateTransition(e,n){if(this._animationsDisabled)return"";switch(e){case h.Init:if(n===h.Checked)return this._animationClasses.uncheckedToChecked;if(n==h.Indeterminate)return this._checked?this._animationClasses.checkedToIndeterminate:this._animationClasses.uncheckedToIndeterminate;break;case h.Unchecked:return n===h.Checked?this._animationClasses.uncheckedToChecked:this._animationClasses.uncheckedToIndeterminate;case h.Checked:return n===h.Unchecked?this._animationClasses.checkedToUnchecked:this._animationClasses.checkedToIndeterminate;case h.Indeterminate:return n===h.Checked?this._animationClasses.indeterminateToChecked:this._animationClasses.indeterminateToUnchecked}return""}_syncIndeterminate(e){let n=this._inputElement;n&&(n.nativeElement.indeterminate=e)}_onInputClick(){this._handleInputClick()}_onTouchTargetClick(){this._handleInputClick(),this.disabled||this._inputElement.nativeElement.focus()}_preventBubblingFromLabel(e){e.target&&this._labelElement.nativeElement.contains(e.target)&&e.stopPropagation()}static \u0275fac=function(n){return new(n||t)};static \u0275cmp=_({type:t,selectors:[["mat-checkbox"]],viewQuery:function(n,a){if(n&1&&ce(lt,5)(ht,5),n&2){let s;q(s=B())&&(a._inputElement=s.first),q(s=B())&&(a._labelElement=s.first)}},hostAttrs:[1,"mat-mdc-checkbox"],hostVars:16,hostBindings:function(n,a){n&2&&(ae("id",a.id),$("tabindex",null)("aria-label",null)("aria-labelledby",null),oe(a.color?"mat-"+a.color:"mat-accent"),M("_mat-animation-noopable",a._animationsDisabled)("mdc-checkbox--disabled",a.disabled)("mat-mdc-checkbox-disabled",a.disabled)("mat-mdc-checkbox-checked",a.checked)("mat-mdc-checkbox-disabled-interactive",a.disabledInteractive))},inputs:{ariaLabel:[0,"aria-label","ariaLabel"],ariaLabelledby:[0,"aria-labelledby","ariaLabelledby"],ariaDescribedby:[0,"aria-describedby","ariaDescribedby"],ariaExpanded:[2,"aria-expanded","ariaExpanded",f],ariaControls:[0,"aria-controls","ariaControls"],ariaOwns:[0,"aria-owns","ariaOwns"],id:"id",required:[2,"required","required",f],labelPosition:"labelPosition",name:"name",value:"value",disableRipple:[2,"disableRipple","disableRipple",f],tabIndex:[2,"tabIndex","tabIndex",e=>e==null?void 0:le(e)],color:"color",disabledInteractive:[2,"disabledInteractive","disabledInteractive",f],checked:[2,"checked","checked",f],disabled:[2,"disabled","disabled",f],indeterminate:[2,"indeterminate","indeterminate",f]},outputs:{change:"change",indeterminateChange:"indeterminateChange"},exportAs:["matCheckbox"],features:[me([{provide:Te,useExisting:Z(()=>t),multi:!0},{provide:Ae,useExisting:t,multi:!0}]),te],ngContentSelectors:bt,decls:15,vars:23,consts:[["checkbox",""],["input",""],["label",""],["mat-internal-form-field","",3,"click","labelPosition"],[1,"mdc-checkbox"],["aria-hidden","true",1,"mat-mdc-checkbox-touch-target",3,"click"],["type","checkbox",1,"mdc-checkbox__native-control",3,"blur","click","change","checked","indeterminate","disabled","id","required","tabIndex"],["aria-hidden","true",1,"mdc-checkbox__ripple"],["aria-hidden","true",1,"mdc-checkbox__background"],["focusable","false","viewBox","0 0 24 24",1,"mdc-checkbox__checkmark"],["fill","none","d","M1.73,12.91 8.1,19.28 22.79,4.59",1,"mdc-checkbox__checkmark-path"],[1,"mdc-checkbox__mixedmark"],["mat-ripple","","aria-hidden","true",1,"mat-mdc-checkbox-ripple","mat-focus-indicator",3,"matRippleTrigger","matRippleDisabled","matRippleCentered"],[1,"mdc-label",3,"for"]],template:function(n,a){if(n&1&&(A(),c(0,"div",3),x("click",function(V){return a._preventBubblingFromLabel(V)}),c(1,"div",4,0)(3,"div",5),x("click",function(){return a._onTouchTargetClick()}),o(),c(4,"input",6,1),x("blur",function(){return a._onBlur()})("click",function(){return a._onInputClick()})("change",function(V){return a._onInteractionEvent(V)}),o(),b(6,"div",7),c(7,"div",8),J(),c(8,"svg",9),b(9,"path",10),o(),W(),b(10,"div",11),o(),b(11,"div",12),o(),c(12,"label",13,2),U(14),o()()),n&2){let s=ie(2);d("labelPosition",a.labelPosition),m(4),M("mdc-checkbox--selected",a.checked),d("checked",a.checked)("indeterminate",a.indeterminate)("disabled",a.disabled&&!a.disabledInteractive)("id",a.inputId)("required",a.required)("tabIndex",a.disabled&&!a.disabledInteractive?-1:a.tabIndex),$("aria-label",a.ariaLabel||null)("aria-labelledby",a.ariaLabelledby)("aria-describedby",a.ariaDescribedby)("aria-checked",a.indeterminate?"mixed":null)("aria-controls",a.ariaControls)("aria-disabled",a.disabled&&a.disabledInteractive?!0:null)("aria-expanded",a.ariaExpanded)("aria-owns",a.ariaOwns)("name",a.name)("value",a.value),m(7),d("matRippleTrigger",s)("matRippleDisabled",a.disableRipple||a.disabled)("matRippleCentered",!0),m(),d("for",a.inputId)}},dependencies:[fe,ot],styles:[`.mdc-checkbox {
  display: inline-block;
  position: relative;
  flex: 0 0 18px;
  box-sizing: content-box;
  width: 18px;
  height: 18px;
  line-height: 0;
  white-space: nowrap;
  cursor: pointer;
  vertical-align: bottom;
  padding: calc((var(--mat-checkbox-state-layer-size, 40px) - 18px) / 2);
  margin: calc((var(--mat-checkbox-state-layer-size, 40px) - var(--mat-checkbox-state-layer-size, 40px)) / 2);
}
.mdc-checkbox:hover > .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-unselected-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
  background-color: var(--mat-checkbox-unselected-hover-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox:hover > .mat-mdc-checkbox-ripple > .mat-ripple-element {
  background-color: var(--mat-checkbox-unselected-hover-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox .mdc-checkbox__native-control:focus + .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-unselected-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
  background-color: var(--mat-checkbox-unselected-focus-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox .mdc-checkbox__native-control:focus ~ .mat-mdc-checkbox-ripple .mat-ripple-element {
  background-color: var(--mat-checkbox-unselected-focus-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox:active > .mdc-checkbox__native-control + .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-unselected-pressed-state-layer-opacity, var(--mat-sys-pressed-state-layer-opacity));
  background-color: var(--mat-checkbox-unselected-pressed-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox:active > .mdc-checkbox__native-control ~ .mat-mdc-checkbox-ripple .mat-ripple-element {
  background-color: var(--mat-checkbox-unselected-pressed-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox:hover > .mdc-checkbox__native-control:checked + .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-selected-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
  background-color: var(--mat-checkbox-selected-hover-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox:hover > .mdc-checkbox__native-control:checked ~ .mat-mdc-checkbox-ripple .mat-ripple-element {
  background-color: var(--mat-checkbox-selected-hover-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox .mdc-checkbox__native-control:focus:checked + .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-selected-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
  background-color: var(--mat-checkbox-selected-focus-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox .mdc-checkbox__native-control:focus:checked ~ .mat-mdc-checkbox-ripple .mat-ripple-element {
  background-color: var(--mat-checkbox-selected-focus-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox:active > .mdc-checkbox__native-control:checked + .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-selected-pressed-state-layer-opacity, var(--mat-sys-pressed-state-layer-opacity));
  background-color: var(--mat-checkbox-selected-pressed-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox:active > .mdc-checkbox__native-control:checked ~ .mat-mdc-checkbox-ripple .mat-ripple-element {
  background-color: var(--mat-checkbox-selected-pressed-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox .mdc-checkbox__native-control ~ .mat-mdc-checkbox-ripple .mat-ripple-element,
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox .mdc-checkbox__native-control + .mdc-checkbox__ripple {
  background-color: var(--mat-checkbox-unselected-hover-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox .mdc-checkbox__native-control {
  position: absolute;
  margin: 0;
  padding: 0;
  opacity: 0;
  cursor: inherit;
  z-index: 1;
  width: var(--mat-checkbox-state-layer-size, 40px);
  height: var(--mat-checkbox-state-layer-size, 40px);
  top: calc((var(--mat-checkbox-state-layer-size, 40px) - var(--mat-checkbox-state-layer-size, 40px)) / 2);
  right: calc((var(--mat-checkbox-state-layer-size, 40px) - var(--mat-checkbox-state-layer-size, 40px)) / 2);
  left: calc((var(--mat-checkbox-state-layer-size, 40px) - var(--mat-checkbox-state-layer-size, 40px)) / 2);
}

.mdc-checkbox--disabled {
  cursor: default;
  pointer-events: none;
}

.mdc-checkbox__background {
  display: inline-flex;
  position: absolute;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  width: 18px;
  height: 18px;
  border: 2px solid currentColor;
  border-radius: 2px;
  background-color: transparent;
  pointer-events: none;
  will-change: background-color, border-color;
  transition: background-color 90ms cubic-bezier(0.4, 0, 0.6, 1), border-color 90ms cubic-bezier(0.4, 0, 0.6, 1);
  -webkit-print-color-adjust: exact;
  color-adjust: exact;
  border-color: var(--mat-checkbox-unselected-icon-color, var(--mat-sys-on-surface-variant));
  top: calc((var(--mat-checkbox-state-layer-size, 40px) - 18px) / 2);
  left: calc((var(--mat-checkbox-state-layer-size, 40px) - 18px) / 2);
}

.mdc-checkbox__native-control:enabled:checked ~ .mdc-checkbox__background,
.mdc-checkbox__native-control:enabled:indeterminate ~ .mdc-checkbox__background {
  border-color: var(--mat-checkbox-selected-icon-color, var(--mat-sys-primary));
  background-color: var(--mat-checkbox-selected-icon-color, var(--mat-sys-primary));
}

.mdc-checkbox--disabled .mdc-checkbox__background {
  border-color: var(--mat-checkbox-disabled-unselected-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
@media (forced-colors: active) {
  .mdc-checkbox--disabled .mdc-checkbox__background {
    border-color: GrayText;
  }
}

.mdc-checkbox__native-control:disabled:checked ~ .mdc-checkbox__background,
.mdc-checkbox__native-control:disabled:indeterminate ~ .mdc-checkbox__background {
  background-color: var(--mat-checkbox-disabled-selected-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
  border-color: transparent;
}
@media (forced-colors: active) {
  .mdc-checkbox__native-control:disabled:checked ~ .mdc-checkbox__background,
  .mdc-checkbox__native-control:disabled:indeterminate ~ .mdc-checkbox__background {
    border-color: GrayText;
  }
}

.mdc-checkbox:hover > .mdc-checkbox__native-control:not(:checked) ~ .mdc-checkbox__background,
.mdc-checkbox:hover > .mdc-checkbox__native-control:not(:indeterminate) ~ .mdc-checkbox__background {
  border-color: var(--mat-checkbox-unselected-hover-icon-color, var(--mat-sys-on-surface));
  background-color: transparent;
}

.mdc-checkbox:hover > .mdc-checkbox__native-control:checked ~ .mdc-checkbox__background,
.mdc-checkbox:hover > .mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background {
  border-color: var(--mat-checkbox-selected-hover-icon-color, var(--mat-sys-primary));
  background-color: var(--mat-checkbox-selected-hover-icon-color, var(--mat-sys-primary));
}

.mdc-checkbox__native-control:focus:focus:not(:checked) ~ .mdc-checkbox__background,
.mdc-checkbox__native-control:focus:focus:not(:indeterminate) ~ .mdc-checkbox__background {
  border-color: var(--mat-checkbox-unselected-focus-icon-color, var(--mat-sys-on-surface));
}

.mdc-checkbox__native-control:focus:focus:checked ~ .mdc-checkbox__background,
.mdc-checkbox__native-control:focus:focus:indeterminate ~ .mdc-checkbox__background {
  border-color: var(--mat-checkbox-selected-focus-icon-color, var(--mat-sys-primary));
  background-color: var(--mat-checkbox-selected-focus-icon-color, var(--mat-sys-primary));
}

.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox:hover > .mdc-checkbox__native-control ~ .mdc-checkbox__background,
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox .mdc-checkbox__native-control:focus ~ .mdc-checkbox__background,
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__background {
  border-color: var(--mat-checkbox-disabled-unselected-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
@media (forced-colors: active) {
  .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox:hover > .mdc-checkbox__native-control ~ .mdc-checkbox__background,
  .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox .mdc-checkbox__native-control:focus ~ .mdc-checkbox__background,
  .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__background {
    border-color: GrayText;
  }
}
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__native-control:checked ~ .mdc-checkbox__background,
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background {
  background-color: var(--mat-checkbox-disabled-selected-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
  border-color: transparent;
}

.mdc-checkbox__checkmark {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  width: 100%;
  opacity: 0;
  transition: opacity 180ms cubic-bezier(0.4, 0, 0.6, 1);
  color: var(--mat-checkbox-selected-checkmark-color, var(--mat-sys-on-primary));
}
@media (forced-colors: active) {
  .mdc-checkbox__checkmark {
    color: CanvasText;
  }
}

.mdc-checkbox--disabled .mdc-checkbox__checkmark, .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__checkmark {
  color: var(--mat-checkbox-disabled-selected-checkmark-color, var(--mat-sys-surface));
}
@media (forced-colors: active) {
  .mdc-checkbox--disabled .mdc-checkbox__checkmark, .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__checkmark {
    color: GrayText;
  }
}

.mdc-checkbox__checkmark-path {
  transition: stroke-dashoffset 180ms cubic-bezier(0.4, 0, 0.6, 1);
  stroke: currentColor;
  stroke-width: 3.12px;
  stroke-dashoffset: 29.7833385;
  stroke-dasharray: 29.7833385;
}

.mdc-checkbox__mixedmark {
  width: 100%;
  height: 0;
  transform: scaleX(0) rotate(0deg);
  border-width: 1px;
  border-style: solid;
  opacity: 0;
  transition: opacity 90ms cubic-bezier(0.4, 0, 0.6, 1), transform 90ms cubic-bezier(0.4, 0, 0.6, 1);
  border-color: var(--mat-checkbox-selected-checkmark-color, var(--mat-sys-on-primary));
}
@media (forced-colors: active) {
  .mdc-checkbox__mixedmark {
    margin: 0 1px;
  }
}

.mdc-checkbox--disabled .mdc-checkbox__mixedmark, .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__mixedmark {
  border-color: var(--mat-checkbox-disabled-selected-checkmark-color, var(--mat-sys-surface));
}
@media (forced-colors: active) {
  .mdc-checkbox--disabled .mdc-checkbox__mixedmark, .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__mixedmark {
    border-color: GrayText;
  }
}

.mdc-checkbox--anim-unchecked-checked .mdc-checkbox__background,
.mdc-checkbox--anim-unchecked-indeterminate .mdc-checkbox__background,
.mdc-checkbox--anim-checked-unchecked .mdc-checkbox__background,
.mdc-checkbox--anim-indeterminate-unchecked .mdc-checkbox__background {
  animation-duration: 180ms;
  animation-timing-function: linear;
}

.mdc-checkbox--anim-unchecked-checked .mdc-checkbox__checkmark-path {
  animation: mdc-checkbox-unchecked-checked-checkmark-path 180ms linear;
  transition: none;
}

.mdc-checkbox--anim-unchecked-indeterminate .mdc-checkbox__mixedmark {
  animation: mdc-checkbox-unchecked-indeterminate-mixedmark 90ms linear;
  transition: none;
}

.mdc-checkbox--anim-checked-unchecked .mdc-checkbox__checkmark-path {
  animation: mdc-checkbox-checked-unchecked-checkmark-path 90ms linear;
  transition: none;
}

.mdc-checkbox--anim-checked-indeterminate .mdc-checkbox__checkmark {
  animation: mdc-checkbox-checked-indeterminate-checkmark 90ms linear;
  transition: none;
}
.mdc-checkbox--anim-checked-indeterminate .mdc-checkbox__mixedmark {
  animation: mdc-checkbox-checked-indeterminate-mixedmark 90ms linear;
  transition: none;
}

.mdc-checkbox--anim-indeterminate-checked .mdc-checkbox__checkmark {
  animation: mdc-checkbox-indeterminate-checked-checkmark 500ms linear;
  transition: none;
}
.mdc-checkbox--anim-indeterminate-checked .mdc-checkbox__mixedmark {
  animation: mdc-checkbox-indeterminate-checked-mixedmark 500ms linear;
  transition: none;
}

.mdc-checkbox--anim-indeterminate-unchecked .mdc-checkbox__mixedmark {
  animation: mdc-checkbox-indeterminate-unchecked-mixedmark 300ms linear;
  transition: none;
}

.mdc-checkbox__native-control:checked ~ .mdc-checkbox__background,
.mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background {
  transition: border-color 90ms cubic-bezier(0, 0, 0.2, 1), background-color 90ms cubic-bezier(0, 0, 0.2, 1);
}
.mdc-checkbox__native-control:checked ~ .mdc-checkbox__background > .mdc-checkbox__checkmark > .mdc-checkbox__checkmark-path,
.mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background > .mdc-checkbox__checkmark > .mdc-checkbox__checkmark-path {
  stroke-dashoffset: 0;
}

.mdc-checkbox__native-control:checked ~ .mdc-checkbox__background > .mdc-checkbox__checkmark {
  transition: opacity 180ms cubic-bezier(0, 0, 0.2, 1), transform 180ms cubic-bezier(0, 0, 0.2, 1);
  opacity: 1;
}
.mdc-checkbox__native-control:checked ~ .mdc-checkbox__background > .mdc-checkbox__mixedmark {
  transform: scaleX(1) rotate(-45deg);
}

.mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background > .mdc-checkbox__checkmark {
  transform: rotate(45deg);
  opacity: 0;
  transition: opacity 90ms cubic-bezier(0.4, 0, 0.6, 1), transform 90ms cubic-bezier(0.4, 0, 0.6, 1);
}
.mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background > .mdc-checkbox__mixedmark {
  transform: scaleX(1) rotate(0deg);
  opacity: 1;
}

@keyframes mdc-checkbox-unchecked-checked-checkmark-path {
  0%, 50% {
    stroke-dashoffset: 29.7833385;
  }
  50% {
    animation-timing-function: cubic-bezier(0, 0, 0.2, 1);
  }
  100% {
    stroke-dashoffset: 0;
  }
}
@keyframes mdc-checkbox-unchecked-indeterminate-mixedmark {
  0%, 68.2% {
    transform: scaleX(0);
  }
  68.2% {
    animation-timing-function: cubic-bezier(0, 0, 0, 1);
  }
  100% {
    transform: scaleX(1);
  }
}
@keyframes mdc-checkbox-checked-unchecked-checkmark-path {
  from {
    animation-timing-function: cubic-bezier(0.4, 0, 1, 1);
    opacity: 1;
    stroke-dashoffset: 0;
  }
  to {
    opacity: 0;
    stroke-dashoffset: -29.7833385;
  }
}
@keyframes mdc-checkbox-checked-indeterminate-checkmark {
  from {
    animation-timing-function: cubic-bezier(0, 0, 0.2, 1);
    transform: rotate(0deg);
    opacity: 1;
  }
  to {
    transform: rotate(45deg);
    opacity: 0;
  }
}
@keyframes mdc-checkbox-indeterminate-checked-checkmark {
  from {
    animation-timing-function: cubic-bezier(0.14, 0, 0, 1);
    transform: rotate(45deg);
    opacity: 0;
  }
  to {
    transform: rotate(360deg);
    opacity: 1;
  }
}
@keyframes mdc-checkbox-checked-indeterminate-mixedmark {
  from {
    animation-timing-function: cubic-bezier(0, 0, 0.2, 1);
    transform: rotate(-45deg);
    opacity: 0;
  }
  to {
    transform: rotate(0deg);
    opacity: 1;
  }
}
@keyframes mdc-checkbox-indeterminate-checked-mixedmark {
  from {
    animation-timing-function: cubic-bezier(0.14, 0, 0, 1);
    transform: rotate(0deg);
    opacity: 1;
  }
  to {
    transform: rotate(315deg);
    opacity: 0;
  }
}
@keyframes mdc-checkbox-indeterminate-unchecked-mixedmark {
  0% {
    animation-timing-function: linear;
    transform: scaleX(1);
    opacity: 1;
  }
  32.8%, 100% {
    transform: scaleX(0);
    opacity: 0;
  }
}
.mat-mdc-checkbox {
  display: inline-block;
  position: relative;
  -webkit-tap-highlight-color: transparent;
}
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mat-mdc-checkbox-touch-target,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__native-control,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__ripple,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mat-mdc-checkbox-ripple::before,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__background,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__background > .mdc-checkbox__checkmark,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__background > .mdc-checkbox__checkmark > .mdc-checkbox__checkmark-path,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__background > .mdc-checkbox__mixedmark {
  transition: none !important;
  animation: none !important;
}
.mat-mdc-checkbox label {
  cursor: pointer;
}
.mat-mdc-checkbox .mat-internal-form-field {
  color: var(--mat-checkbox-label-text-color, var(--mat-sys-on-surface));
  font-family: var(--mat-checkbox-label-text-font, var(--mat-sys-body-medium-font));
  line-height: var(--mat-checkbox-label-text-line-height, var(--mat-sys-body-medium-line-height));
  font-size: var(--mat-checkbox-label-text-size, var(--mat-sys-body-medium-size));
  letter-spacing: var(--mat-checkbox-label-text-tracking, var(--mat-sys-body-medium-tracking));
  font-weight: var(--mat-checkbox-label-text-weight, var(--mat-sys-body-medium-weight));
}
.mat-mdc-checkbox.mat-mdc-checkbox-disabled.mat-mdc-checkbox-disabled-interactive {
  pointer-events: auto;
}
.mat-mdc-checkbox.mat-mdc-checkbox-disabled.mat-mdc-checkbox-disabled-interactive input {
  cursor: default;
}
.mat-mdc-checkbox.mat-mdc-checkbox-disabled label {
  cursor: default;
  color: var(--mat-checkbox-disabled-label-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
@media (forced-colors: active) {
  .mat-mdc-checkbox.mat-mdc-checkbox-disabled label {
    color: GrayText;
  }
}
.mat-mdc-checkbox label:empty {
  display: none;
}
.mat-mdc-checkbox .mdc-checkbox__ripple {
  opacity: 0;
}

.mat-mdc-checkbox .mat-mdc-checkbox-ripple,
.mdc-checkbox__ripple {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  border-radius: 50%;
  pointer-events: none;
}
.mat-mdc-checkbox .mat-mdc-checkbox-ripple:not(:empty),
.mdc-checkbox__ripple:not(:empty) {
  transform: translateZ(0);
}

.mat-mdc-checkbox-ripple .mat-ripple-element {
  opacity: 0.1;
}

.mat-mdc-checkbox-touch-target {
  position: absolute;
  top: 50%;
  left: 50%;
  height: var(--mat-checkbox-touch-target-size, 48px);
  width: var(--mat-checkbox-touch-target-size, 48px);
  transform: translate(-50%, -50%);
  display: var(--mat-checkbox-touch-target-display, block);
}

.mat-mdc-checkbox .mat-mdc-checkbox-ripple::before {
  border-radius: 50%;
}

.mdc-checkbox__native-control:focus-visible ~ .mat-focus-indicator::before {
  content: "";
}
`],encapsulation:2,changeDetection:0})}return t})(),rt=(()=>{class t{static \u0275fac=function(n){return new(n||t)};static \u0275mod=T({type:t});static \u0275inj=I({imports:[kt,ye]})}return t})();function yt(t,i){t&1&&b(0,"mat-progress-bar",6)}function Ct(t,i){if(t&1&&(c(0,"div",7)(1,"mat-card",8)(2,"mat-card-content")(3,"div",9)(4,"mat-icon",10),r(5,"group"),o()(),c(6,"div",11),r(7),o(),c(8,"div",12),r(9,"Total Users"),o()()(),c(10,"mat-card",13)(11,"mat-card-content")(12,"div",9)(13,"mat-icon",10),r(14,"school"),o()(),c(15,"div",11),r(16),o(),c(17,"div",12),r(18,"Active Instructors"),o()()(),c(19,"mat-card",14)(20,"mat-card-content")(21,"div",9)(22,"mat-icon",10),r(23,"person"),o()(),c(24,"div",11),r(25),o(),c(26,"div",12),r(27,"Registered Students"),o()()()()),t&2){let e=l();m(7),k(e.stats.totalUsers),m(9),k(e.stats.totalInstructors),m(9),k(e.stats.totalStudents)}}var F=class t{constructor(i){this.http=i}stats={totalUsers:0,totalInstructors:0,totalStudents:0};isLoading=!0;ngOnInit(){this.http.get(`${g.apiUrl}/auth/users`).subscribe({next:i=>{this.stats={totalUsers:i.length,totalInstructors:i.filter(e=>e.role==="Instructor").length,totalStudents:i.filter(e=>e.role==="Student").length},this.isLoading=!1},error:()=>{this.isLoading=!1}})}static \u0275fac=function(e){return new(e||t)(C(D))};static \u0275cmp=_({type:t,selectors:[["app-platform-analytics"]],standalone:!1,decls:13,vars:2,consts:[[1,"analytics-page"],[1,"page-header"],["mode","indeterminate",4,"ngIf"],["class","kpi-grid",4,"ngIf"],[1,"quick-links"],["mat-raised-button","","color","primary","routerLink","/admin/users"],["mode","indeterminate"],[1,"kpi-grid"],["data-cy","kpi-total-users",1,"kpi-card"],[1,"kpi-icon-wrap"],[1,"kpi-icon"],[1,"kpi-value"],[1,"kpi-label"],["data-cy","kpi-active-instructors",1,"kpi-card"],["data-cy","kpi-registered-students",1,"kpi-card"]],template:function(e,n){e&1&&(c(0,"div",0)(1,"div",1)(2,"h1"),r(3,"Platform Analytics"),o(),c(4,"p"),r(5,"Admin overview \u2014 moderation and user metrics"),o()(),p(6,yt,1,0,"mat-progress-bar",2)(7,Ct,28,3,"div",3),c(8,"div",4)(9,"a",5)(10,"mat-icon"),r(11,"manage_accounts"),o(),r(12," Manage Users "),o()()()),e&2&&(m(6),d("ngIf",n.isLoading),m(),d("ngIf",!n.isLoading))},dependencies:[P,pe,Ce,Ie,Ee,O,z],styles:[".analytics-page[_ngcontent-%COMP%]{padding:40px;max-width:1200px;margin:0 auto}.page-header[_ngcontent-%COMP%]{margin-bottom:32px}.page-header[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%]{font-size:2rem;color:#1e3a5f;margin:0}.kpi-grid[_ngcontent-%COMP%]{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:24px;margin-bottom:40px}.kpi-card[_ngcontent-%COMP%]{text-align:center;padding:16px;border-top:4px solid #2E75B6}.kpi-icon-wrap[_ngcontent-%COMP%]{width:48px;height:48px;margin:0 auto 10px;display:flex;align-items:center;justify-content:center}.kpi-icon[_ngcontent-%COMP%]{font-size:30px;width:30px;height:30px;line-height:30px;color:#2e75b6}.kpi-value[_ngcontent-%COMP%]{font-size:2rem;font-weight:700;color:#1e3a5f;margin-bottom:4px}.kpi-label[_ngcontent-%COMP%]{color:#666;font-size:.9rem}.quick-links[_ngcontent-%COMP%]{display:flex;gap:16px;flex-wrap:wrap}"]})};function Mt(t,i){if(t&1&&(c(0,"div",15),r(1),o()),t&2){let e=l();m(),k(e.actionMessage)}}function It(t,i){if(t&1&&(c(0,"div",16),r(1),o()),t&2){let e=l();m(),k(e.actionError)}}function Et(t,i){t&1&&b(0,"mat-progress-bar",17)}function St(t,i){t&1&&(c(0,"mat-header-cell"),r(1,"Name"),o())}function Tt(t,i){if(t&1&&(c(0,"mat-cell"),r(1),o()),t&2){let e=i.$implicit;m(),k(e.fullName)}}function wt(t,i){t&1&&(c(0,"mat-header-cell"),r(1,"Email"),o())}function At(t,i){if(t&1&&(c(0,"mat-cell"),r(1),o()),t&2){let e=i.$implicit;m(),k(e.email)}}function Ut(t,i){t&1&&(c(0,"mat-header-cell"),r(1,"Role"),o())}function Pt(t,i){if(t&1&&(c(0,"mat-cell")(1,"mat-chip",28),r(2),o()()),t&2){let e=i.$implicit;m(2),k(e.role)}}function Dt(t,i){t&1&&(c(0,"mat-header-cell"),r(1,"Status"),o())}function Ot(t,i){if(t&1&&(c(0,"mat-cell")(1,"mat-chip",29),r(2),o()()),t&2){let e=i.$implicit;m(),d("ngClass",e.isActive?"status-active":"status-suspended"),m(),re(" ",e.isActive?"Active":"Suspended"," ")}}function zt(t,i){t&1&&(c(0,"mat-header-cell"),r(1,"Actions"),o())}function Lt(t,i){if(t&1){let e=w();c(0,"button",33),x("click",function(){E(e);let a=l().$implicit,s=l(2);return S(s.suspend(a.id))}),c(1,"mat-icon"),r(2,"block"),o()()}if(t&2){let e=l().$implicit,n=l(2);d("disabled",n.isActionLoading||e.role==="Admin"||n.isCurrentUser(e.id))}}function Ft(t,i){if(t&1){let e=w();c(0,"button",34),x("click",function(){E(e);let a=l().$implicit,s=l(2);return S(s.unsuspend(a.id))}),c(1,"mat-icon"),r(2,"check_circle"),o()()}if(t&2){let e=l().$implicit,n=l(2);d("disabled",n.isActionLoading||e.role==="Admin"||n.isCurrentUser(e.id))}}function Rt(t,i){if(t&1){let e=w();c(0,"mat-cell"),p(1,Lt,3,1,"button",30)(2,Ft,3,1,"button",31),c(3,"button",32),x("click",function(){let a=E(e).$implicit,s=l(2);return S(s.delete(a.id))}),c(4,"mat-icon"),r(5,"delete"),o()()()}if(t&2){let e=i.$implicit,n=l(2);m(),d("ngIf",e.isActive),m(),d("ngIf",!e.isActive),m(),d("disabled",n.isActionLoading||e.role==="Admin"||n.isCurrentUser(e.id))}}function Vt(t,i){t&1&&b(0,"mat-header-row")}function Nt(t,i){t&1&&b(0,"mat-row")}function $t(t,i){if(t&1&&(c(0,"mat-table",18),v(1,19),p(2,St,2,0,"mat-header-cell",20)(3,Tt,2,1,"mat-cell",21),y(),v(4,22),p(5,wt,2,0,"mat-header-cell",20)(6,At,2,1,"mat-cell",21),y(),v(7,23),p(8,Ut,2,0,"mat-header-cell",20)(9,Pt,3,1,"mat-cell",21),y(),v(10,24),p(11,Dt,2,0,"mat-header-cell",20)(12,Ot,3,2,"mat-cell",21),y(),v(13,25),p(14,zt,2,0,"mat-header-cell",20)(15,Rt,6,3,"mat-cell",21),y(),p(16,Vt,1,0,"mat-header-row",26)(17,Nt,1,0,"mat-row",27),o()),t&2){let e=l();d("dataSource",e.users),m(16),d("matHeaderRowDef",e.displayedColumns),m(),d("matRowDefColumns",e.displayedColumns)}}var R=class t{constructor(i,e){this.http=i;this.authService=e}users=[];isLoading=!0;isActionLoading=!1;actionMessage="";actionError="";currentUserId="";searchControl=new H("");roleControl=new H("");displayedColumns=["name","email","role","status","actions"];ngOnInit(){this.currentUserId=this.authService.getProfile()?.id??"",this.loadUsers(),this.searchControl.valueChanges.pipe(X(300),Q()).subscribe(()=>this.loadUsers()),this.roleControl.valueChanges.subscribe(()=>this.loadUsers())}loadUsers(){this.isLoading=!0;let i=`${g.apiUrl}/auth/users?`;this.searchControl.value&&(i+=`q=${this.searchControl.value}&`),this.roleControl.value&&(i+=`role=${this.roleControl.value}`),this.http.get(i).subscribe({next:e=>{this.users=e,this.isLoading=!1},error:()=>{this.isLoading=!1,this.actionError="Failed to load users."}})}suspend(i){this.resetFeedback(),this.isActionLoading=!0,this.http.put(`${g.apiUrl}/admin/users/${i}/suspend`,{}).subscribe({next:()=>{this.actionMessage="User suspended successfully.",this.isActionLoading=!1,this.loadUsers()},error:e=>{this.actionError=e.error?.message||"Failed to suspend user.",this.isActionLoading=!1}})}unsuspend(i){this.resetFeedback(),this.isActionLoading=!0,this.http.put(`${g.apiUrl}/admin/users/${i}/unsuspend`,{}).subscribe({next:()=>{this.actionMessage="User unsuspended successfully.",this.isActionLoading=!1,this.loadUsers()},error:e=>{this.actionError=e.error?.message||"Failed to unsuspend user.",this.isActionLoading=!1}})}delete(i){confirm("Are you sure you want to delete this user?")&&(this.resetFeedback(),this.isActionLoading=!0,this.http.delete(`${g.apiUrl}/admin/users/${i}`).subscribe({next:()=>{this.actionMessage="User deleted successfully.",this.isActionLoading=!1,this.loadUsers()},error:e=>{this.actionError=e.error?.message||"Failed to delete user.",this.isActionLoading=!1}}))}isCurrentUser(i){return!!this.currentUserId&&this.currentUserId===i}resetFeedback(){this.actionMessage="",this.actionError=""}static \u0275fac=function(e){return new(e||t)(C(D),C(Xe))};static \u0275cmp=_({type:t,selectors:[["app-user-management"]],standalone:!1,decls:27,vars:6,consts:[[1,"users-page"],[1,"page-header"],[1,"filters"],["appearance","outline"],["matInput","","placeholder","Name or email",3,"formControl"],["matSuffix",""],[3,"formControl"],["value",""],["value","Student"],["value","Instructor"],["value","Admin"],["class","banner success",4,"ngIf"],["class","banner error",4,"ngIf"],["mode","indeterminate",4,"ngIf"],["class","users-table",3,"dataSource",4,"ngIf"],[1,"banner","success"],[1,"banner","error"],["mode","indeterminate"],[1,"users-table",3,"dataSource"],["matColumnDef","name"],[4,"matHeaderCellDef"],[4,"matCellDef"],["matColumnDef","email"],["matColumnDef","role"],["matColumnDef","status"],["matColumnDef","actions"],[4,"matHeaderRowDef"],[4,"matRowDef","matRowDefColumns"],[1,"role-chip"],[1,"status-chip",3,"ngClass"],["mat-icon-button","","matTooltip","Suspend",3,"disabled","click",4,"ngIf"],["mat-icon-button","","matTooltip","Unsuspend","color","accent",3,"disabled","click",4,"ngIf"],["mat-icon-button","","color","warn","matTooltip","Delete",3,"click","disabled"],["mat-icon-button","","matTooltip","Suspend",3,"click","disabled"],["mat-icon-button","","matTooltip","Unsuspend","color","accent",3,"click","disabled"]],template:function(e,n){e&1&&(c(0,"div",0)(1,"div",1)(2,"h1"),r(3,"User Management"),o()(),c(4,"div",2)(5,"mat-form-field",3)(6,"mat-label"),r(7,"Search users"),o(),b(8,"input",4),c(9,"mat-icon",5),r(10,"search"),o()(),c(11,"mat-form-field",3)(12,"mat-label"),r(13,"Filter by role"),o(),c(14,"mat-select",6)(15,"mat-option",7),r(16,"All Roles"),o(),c(17,"mat-option",8),r(18,"Student"),o(),c(19,"mat-option",9),r(20,"Instructor"),o(),c(21,"mat-option",10),r(22,"Admin"),o()()()(),p(23,Mt,2,1,"div",11)(24,It,2,1,"div",12)(25,Et,1,0,"mat-progress-bar",13)(26,$t,18,3,"mat-table",14),o()),e&2&&(m(8),d("formControl",n.searchControl),m(6),d("formControl",n.roleControl),m(9),d("ngIf",n.actionMessage),m(),d("ngIf",n.actionError),m(),d("ngIf",n.isLoading),m(),d("ngIf",!n.isLoading))},dependencies:[he,P,we,Ue,Pe,ve,Fe,Le,Oe,ze,O,Ne,Ve,Ze,Je,tt,We,Ke,nt,Ye,et,at,ct,Be,z],styles:[".users-page[_ngcontent-%COMP%]{padding:40px;max-width:1200px;margin:0 auto}.page-header[_ngcontent-%COMP%]{margin-bottom:24px}.page-header[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%]{font-size:2rem;color:#1e3a5f;margin:0}.filters[_ngcontent-%COMP%]{display:flex;gap:16px;margin-bottom:24px}.users-table[_ngcontent-%COMP%]{width:100%}.banner[_ngcontent-%COMP%]{padding:10px 14px;border-radius:10px;margin-bottom:12px;font-size:.95rem}.banner.success[_ngcontent-%COMP%]{background:#16a34a26;border:1px solid rgba(34,197,94,.4);color:#86efac}.banner.error[_ngcontent-%COMP%]{background:#dc262626;border:1px solid rgba(248,113,113,.5);color:#fecaca}[_nghost-%COMP%]     .users-table .mat-mdc-cell, [_nghost-%COMP%]     .users-table .mdc-data-table__cell{color:#e5e7eb!important}[_nghost-%COMP%]     .users-table .mat-mdc-header-cell, [_nghost-%COMP%]     .users-table .mdc-data-table__header-cell{color:#cbd5e1!important}[_nghost-%COMP%]     .role-chip, [_nghost-%COMP%]     .status-chip{color:#e5e7eb!important;border:1px solid rgba(148,163,184,.28);background:#1e293bb3!important}[_nghost-%COMP%]     .status-active{background:#16a34a2e!important;border-color:#22c55e80;color:#bbf7d0!important}[_nghost-%COMP%]     .status-suspended{background:#ef444426!important;border-color:#f8717173;color:#fecaca!important}"]})};var qt=[{path:"analytics",component:F},{path:"users",component:R},{path:"",redirectTo:"analytics",pathMatch:"full"}],mt=class t{static \u0275fac=function(e){return new(e||t)};static \u0275mod=T({type:t});static \u0275inj=I({imports:[be,De,ke.forChild(qt),Me,Se,Re,je,$e,it,He,Ge,qe,rt,Qe]})};export{mt as AdminModule};
