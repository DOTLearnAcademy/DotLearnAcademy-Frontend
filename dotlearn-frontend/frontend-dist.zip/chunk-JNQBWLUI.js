import{b as gt}from"./chunk-YA66VBDX.js";import{a as K,b as J,c as W,d as Y,e as ee,f as te,g as ne,h as ae,i as ie,j as oe,k as St}from"./chunk-ZVPMZFUZ.js";import{a as vt,b as yt}from"./chunk-34NWVUUL.js";import"./chunk-Y7TSOQ34.js";import{a as Q,b as Z,c as xt}from"./chunk-OQWW5O2R.js";import"./chunk-DSWEZWRZ.js";import{a as P,b as Mt}from"./chunk-3TVKKZX5.js";import{b as It}from"./chunk-GEESYIHI.js";import{C as ut,D as _t,E as q,G as kt,J as G,N as X,O as ft,a as V,b as ot,c as H,f as ct,g as rt,h as mt,j as B,k as lt,l as $,n as j,o as st,q as _e,r as dt,t as pt,w as ht,x as bt}from"./chunk-7ZMES55J.js";import{H as Je,R as We,Z as Ye,ba as et,da as tt,e as I,ea as nt,ga as at,h as qe,i as Ge,ia as A,j as Xe,k as Qe,ka as it,p as S,v as Ze,xa as E,y as Ke,ya as Ct,za as k}from"./chunk-3MDBR2PL.js";import{$b as Ue,Aa as pe,Ac as R,Ba as De,Bb as d,Bc as Le,Cc as Ve,Dc as He,Ea as Ae,J as Me,Ja as Pe,Kb as he,Kc as Be,Ma as Oe,N as Ie,Qb as l,Rb as a,Rc as $e,Sb as n,Tb as p,Uc as M,Vc as je,Xb as x,Yb as g,_b as D,a as de,cc as u,ec as b,fc as N,ga as Se,gc as L,hb as m,ia as z,ic as Re,jc as be,ka as Ee,kc as ue,ma as C,oc as ze,qb as v,qc as U,rc as Fe,sa as w,sc as o,ta as T,tc as _,ua as we,uc as y,va as Te,wb as f,xb as F,xc as Ne}from"./chunk-GZG6EVBY.js";var At=["mat-internal-form-field",""],Pt=["*"],Et=(()=>{class t{labelPosition="after";static \u0275fac=function(c){return new(c||t)};static \u0275cmp=f({type:t,selectors:[["div","mat-internal-form-field",""]],hostAttrs:[1,"mdc-form-field","mat-internal-form-field"],hostVars:2,hostBindings:function(c,r){c&2&&U("mdc-form-field--align-end",r.labelPosition==="before")},inputs:{labelPosition:"labelPosition"},attrs:At,ngContentSelectors:Pt,decls:1,vars:0,template:function(c,r){c&1&&(N(),L(0))},styles:[`.mat-internal-form-field {
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  display: inline-flex;
  align-items: center;
  vertical-align: middle;
}
.mat-internal-form-field > label {
  margin-left: 0;
  margin-right: auto;
  padding-left: 4px;
  padding-right: 0;
  order: 0;
}
[dir=rtl] .mat-internal-form-field > label {
  margin-left: auto;
  margin-right: 0;
  padding-left: 0;
  padding-right: 4px;
}

.mdc-form-field--align-end > label {
  margin-left: auto;
  margin-right: 0;
  padding-left: 0;
  padding-right: 4px;
  order: -1;
}
[dir=rtl] .mdc-form-field--align-end .mdc-form-field--align-end label {
  margin-left: 0;
  margin-right: auto;
  padding-left: 4px;
  padding-right: 0;
}
`],encapsulation:2,changeDetection:0})}return t})();var Ot=["input"],Ut=["label"],Rt=["*"],ke={color:"accent",clickAction:"check-indeterminate",disabledInteractive:!1},zt=new Ee("mat-checkbox-default-options",{providedIn:"root",factory:()=>ke}),h=(function(t){return t[t.Init=0]="Init",t[t.Checked=1]="Checked",t[t.Unchecked=2]="Unchecked",t[t.Indeterminate=3]="Indeterminate",t})(h||{}),fe=class{source;checked},Ft=(()=>{class t{_elementRef=C(Oe);_changeDetectorRef=C($e);_ngZone=C(De);_animationsDisabled=Ye();_options=C(zt,{optional:!0});focus(){this._inputElement.nativeElement.focus()}_createChangeEvent(e){let c=new fe;return c.source=this,c.checked=e,c}_getAnimationTargetElement(){return this._inputElement?.nativeElement}_animationClasses={uncheckedToChecked:"mdc-checkbox--anim-unchecked-checked",uncheckedToIndeterminate:"mdc-checkbox--anim-unchecked-indeterminate",checkedToUnchecked:"mdc-checkbox--anim-checked-unchecked",checkedToIndeterminate:"mdc-checkbox--anim-checked-indeterminate",indeterminateToChecked:"mdc-checkbox--anim-indeterminate-checked",indeterminateToUnchecked:"mdc-checkbox--anim-indeterminate-unchecked"};ariaLabel="";ariaLabelledby=null;ariaDescribedby;ariaExpanded;ariaControls;ariaOwns;_uniqueId;id;get inputId(){return`${this.id||this._uniqueId}-input`}required=!1;labelPosition="after";name=null;change=new pe;indeterminateChange=new pe;value;disableRipple=!1;_inputElement;_labelElement;tabIndex;color;disabledInteractive;_onTouched=()=>{};_currentAnimationClass="";_currentCheckState=h.Init;_controlValueAccessorChangeFn=()=>{};_validatorChangeFn=()=>{};constructor(){C(Je).load(tt);let e=C(new Be("tabindex"),{optional:!0});this._options=this._options||ke,this.color=this._options.color||ke.color,this.tabIndex=e==null?0:parseInt(e)||0,this.id=this._uniqueId=C(We).getId("mat-mdc-checkbox-"),this.disabledInteractive=this._options?.disabledInteractive??!1}ngOnChanges(e){e.required&&this._validatorChangeFn()}ngAfterViewInit(){this._syncIndeterminate(this.indeterminate)}get checked(){return this._checked}set checked(e){e!=this.checked&&(this._checked=e,this._changeDetectorRef.markForCheck())}_checked=!1;get disabled(){return this._disabled}set disabled(e){e!==this.disabled&&(this._disabled=e,this._changeDetectorRef.markForCheck())}_disabled=!1;get indeterminate(){return this._indeterminate()}set indeterminate(e){let c=e!=this._indeterminate();this._indeterminate.set(e),c&&(e?this._transitionCheckState(h.Indeterminate):this._transitionCheckState(this.checked?h.Checked:h.Unchecked),this.indeterminateChange.emit(e)),this._syncIndeterminate(e)}_indeterminate=Ae(!1);_isRippleDisabled(){return this.disableRipple||this.disabled}_onLabelTextChange(){this._changeDetectorRef.detectChanges()}writeValue(e){this.checked=!!e}registerOnChange(e){this._controlValueAccessorChangeFn=e}registerOnTouched(e){this._onTouched=e}setDisabledState(e){this.disabled=e}validate(e){return this.required&&e.value!==!0?{required:!0}:null}registerOnValidatorChange(e){this._validatorChangeFn=e}_transitionCheckState(e){let c=this._currentCheckState,r=this._getAnimationTargetElement();if(!(c===e||!r)&&(this._currentAnimationClass&&r.classList.remove(this._currentAnimationClass),this._currentAnimationClass=this._getAnimationClassForCheckStateTransition(c,e),this._currentCheckState=e,this._currentAnimationClass.length>0)){r.classList.add(this._currentAnimationClass);let s=this._currentAnimationClass;this._ngZone.runOutsideAngular(()=>{setTimeout(()=>{r.classList.remove(s)},1e3)})}}_emitChangeEvent(){this._controlValueAccessorChangeFn(this.checked),this.change.emit(this._createChangeEvent(this.checked)),this._inputElement&&(this._inputElement.nativeElement.checked=this.checked)}toggle(){this.checked=!this.checked,this._controlValueAccessorChangeFn(this.checked)}_handleInputClick(){let e=this._options?.clickAction;!this.disabled&&e!=="noop"?(this.indeterminate&&e!=="check"&&Promise.resolve().then(()=>{this._indeterminate.set(!1),this.indeterminateChange.emit(!1)}),this._checked=!this._checked,this._transitionCheckState(this._checked?h.Checked:h.Unchecked),this._emitChangeEvent()):(this.disabled&&this.disabledInteractive||!this.disabled&&e==="noop")&&(this._inputElement.nativeElement.checked=this.checked,this._inputElement.nativeElement.indeterminate=this.indeterminate)}_onInteractionEvent(e){e.stopPropagation()}_onBlur(){Promise.resolve().then(()=>{this._onTouched(),this._changeDetectorRef.markForCheck()})}_getAnimationClassForCheckStateTransition(e,c){if(this._animationsDisabled)return"";switch(e){case h.Init:if(c===h.Checked)return this._animationClasses.uncheckedToChecked;if(c==h.Indeterminate)return this._checked?this._animationClasses.checkedToIndeterminate:this._animationClasses.uncheckedToIndeterminate;break;case h.Unchecked:return c===h.Checked?this._animationClasses.uncheckedToChecked:this._animationClasses.uncheckedToIndeterminate;case h.Checked:return c===h.Unchecked?this._animationClasses.checkedToUnchecked:this._animationClasses.checkedToIndeterminate;case h.Indeterminate:return c===h.Checked?this._animationClasses.indeterminateToChecked:this._animationClasses.indeterminateToUnchecked}return""}_syncIndeterminate(e){let c=this._inputElement;c&&(c.nativeElement.indeterminate=e)}_onInputClick(){this._handleInputClick()}_onTouchTargetClick(){this._handleInputClick(),this.disabled||this._inputElement.nativeElement.focus()}_preventBubblingFromLabel(e){e.target&&this._labelElement.nativeElement.contains(e.target)&&e.stopPropagation()}static \u0275fac=function(c){return new(c||t)};static \u0275cmp=f({type:t,selectors:[["mat-checkbox"]],viewQuery:function(c,r){if(c&1&&Re(Ot,5)(Ut,5),c&2){let s;be(s=ue())&&(r._inputElement=s.first),be(s=ue())&&(r._labelElement=s.first)}},hostAttrs:[1,"mat-mdc-checkbox"],hostVars:16,hostBindings:function(c,r){c&2&&(Ue("id",r.id),he("tabindex",null)("aria-label",null)("aria-labelledby",null),Fe(r.color?"mat-"+r.color:"mat-accent"),U("_mat-animation-noopable",r._animationsDisabled)("mdc-checkbox--disabled",r.disabled)("mat-mdc-checkbox-disabled",r.disabled)("mat-mdc-checkbox-checked",r.checked)("mat-mdc-checkbox-disabled-interactive",r.disabledInteractive))},inputs:{ariaLabel:[0,"aria-label","ariaLabel"],ariaLabelledby:[0,"aria-labelledby","ariaLabelledby"],ariaDescribedby:[0,"aria-describedby","ariaDescribedby"],ariaExpanded:[2,"aria-expanded","ariaExpanded",M],ariaControls:[0,"aria-controls","ariaControls"],ariaOwns:[0,"aria-owns","ariaOwns"],id:"id",required:[2,"required","required",M],labelPosition:"labelPosition",name:"name",value:"value",disableRipple:[2,"disableRipple","disableRipple",M],tabIndex:[2,"tabIndex","tabIndex",e=>e==null?void 0:je(e)],color:"color",disabledInteractive:[2,"disabledInteractive","disabledInteractive",M],checked:[2,"checked","checked",M],disabled:[2,"disabled","disabled",M],indeterminate:[2,"indeterminate","indeterminate",M]},outputs:{change:"change",indeterminateChange:"indeterminateChange"},exportAs:["matCheckbox"],features:[Ne([{provide:mt,useExisting:Se(()=>t),multi:!0},{provide:lt,useExisting:t,multi:!0}]),Pe],ngContentSelectors:Rt,decls:15,vars:23,consts:[["checkbox",""],["input",""],["label",""],["mat-internal-form-field","",3,"click","labelPosition"],[1,"mdc-checkbox"],["aria-hidden","true",1,"mat-mdc-checkbox-touch-target",3,"click"],["type","checkbox",1,"mdc-checkbox__native-control",3,"blur","click","change","checked","indeterminate","disabled","id","required","tabIndex"],["aria-hidden","true",1,"mdc-checkbox__ripple"],["aria-hidden","true",1,"mdc-checkbox__background"],["focusable","false","viewBox","0 0 24 24",1,"mdc-checkbox__checkmark"],["fill","none","d","M1.73,12.91 8.1,19.28 22.79,4.59",1,"mdc-checkbox__checkmark-path"],[1,"mdc-checkbox__mixedmark"],["mat-ripple","","aria-hidden","true",1,"mat-mdc-checkbox-ripple","mat-focus-indicator",3,"matRippleTrigger","matRippleDisabled","matRippleCentered"],[1,"mdc-label",3,"for"]],template:function(c,r){if(c&1&&(N(),a(0,"div",3),u("click",function(se){return r._preventBubblingFromLabel(se)}),a(1,"div",4,0)(3,"div",5),u("click",function(){return r._onTouchTargetClick()}),n(),a(4,"input",6,1),u("blur",function(){return r._onBlur()})("click",function(){return r._onInputClick()})("change",function(se){return r._onInteractionEvent(se)}),n(),p(6,"div",7),a(7,"div",8),we(),a(8,"svg",9),p(9,"path",10),n(),Te(),p(10,"div",11),n(),p(11,"div",12),n(),a(12,"label",13,2),L(14),n()()),c&2){let s=ze(2);l("labelPosition",r.labelPosition),m(4),U("mdc-checkbox--selected",r.checked),l("checked",r.checked)("indeterminate",r.indeterminate)("disabled",r.disabled&&!r.disabledInteractive)("id",r.inputId)("required",r.required)("tabIndex",r.disabled&&!r.disabledInteractive?-1:r.tabIndex),he("aria-label",r.ariaLabel||null)("aria-labelledby",r.ariaLabelledby)("aria-describedby",r.ariaDescribedby)("aria-checked",r.indeterminate?"mixed":null)("aria-controls",r.ariaControls)("aria-disabled",r.disabled&&r.disabledInteractive?!0:null)("aria-expanded",r.ariaExpanded)("aria-owns",r.ariaOwns)("name",r.name)("value",r.value),m(7),l("matRippleTrigger",s)("matRippleDisabled",r.disableRipple||r.disabled)("matRippleCentered",!0),m(),l("for",r.inputId)}},dependencies:[et,Et],styles:[`.mdc-checkbox {
  display: inline-block;
  position: relative;
  flex: 0 0 18px;
  box-sizing: content-box;
  width: 18px;
  height: 18px;
  line-height: 0;
  white-space: nowrap;
  cursor: pointer;
  vertical-align: bottom;
  padding: calc((var(--mat-checkbox-state-layer-size, 40px) - 18px) / 2);
  margin: calc((var(--mat-checkbox-state-layer-size, 40px) - var(--mat-checkbox-state-layer-size, 40px)) / 2);
}
.mdc-checkbox:hover > .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-unselected-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
  background-color: var(--mat-checkbox-unselected-hover-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox:hover > .mat-mdc-checkbox-ripple > .mat-ripple-element {
  background-color: var(--mat-checkbox-unselected-hover-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox .mdc-checkbox__native-control:focus + .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-unselected-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
  background-color: var(--mat-checkbox-unselected-focus-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox .mdc-checkbox__native-control:focus ~ .mat-mdc-checkbox-ripple .mat-ripple-element {
  background-color: var(--mat-checkbox-unselected-focus-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox:active > .mdc-checkbox__native-control + .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-unselected-pressed-state-layer-opacity, var(--mat-sys-pressed-state-layer-opacity));
  background-color: var(--mat-checkbox-unselected-pressed-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox:active > .mdc-checkbox__native-control ~ .mat-mdc-checkbox-ripple .mat-ripple-element {
  background-color: var(--mat-checkbox-unselected-pressed-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox:hover > .mdc-checkbox__native-control:checked + .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-selected-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
  background-color: var(--mat-checkbox-selected-hover-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox:hover > .mdc-checkbox__native-control:checked ~ .mat-mdc-checkbox-ripple .mat-ripple-element {
  background-color: var(--mat-checkbox-selected-hover-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox .mdc-checkbox__native-control:focus:checked + .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-selected-focus-state-layer-opacity, var(--mat-sys-focus-state-layer-opacity));
  background-color: var(--mat-checkbox-selected-focus-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox .mdc-checkbox__native-control:focus:checked ~ .mat-mdc-checkbox-ripple .mat-ripple-element {
  background-color: var(--mat-checkbox-selected-focus-state-layer-color, var(--mat-sys-primary));
}
.mdc-checkbox:active > .mdc-checkbox__native-control:checked + .mdc-checkbox__ripple {
  opacity: var(--mat-checkbox-selected-pressed-state-layer-opacity, var(--mat-sys-pressed-state-layer-opacity));
  background-color: var(--mat-checkbox-selected-pressed-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox:active > .mdc-checkbox__native-control:checked ~ .mat-mdc-checkbox-ripple .mat-ripple-element {
  background-color: var(--mat-checkbox-selected-pressed-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox .mdc-checkbox__native-control ~ .mat-mdc-checkbox-ripple .mat-ripple-element,
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox .mdc-checkbox__native-control + .mdc-checkbox__ripple {
  background-color: var(--mat-checkbox-unselected-hover-state-layer-color, var(--mat-sys-on-surface));
}
.mdc-checkbox .mdc-checkbox__native-control {
  position: absolute;
  margin: 0;
  padding: 0;
  opacity: 0;
  cursor: inherit;
  z-index: 1;
  width: var(--mat-checkbox-state-layer-size, 40px);
  height: var(--mat-checkbox-state-layer-size, 40px);
  top: calc((var(--mat-checkbox-state-layer-size, 40px) - var(--mat-checkbox-state-layer-size, 40px)) / 2);
  right: calc((var(--mat-checkbox-state-layer-size, 40px) - var(--mat-checkbox-state-layer-size, 40px)) / 2);
  left: calc((var(--mat-checkbox-state-layer-size, 40px) - var(--mat-checkbox-state-layer-size, 40px)) / 2);
}

.mdc-checkbox--disabled {
  cursor: default;
  pointer-events: none;
}

.mdc-checkbox__background {
  display: inline-flex;
  position: absolute;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  width: 18px;
  height: 18px;
  border: 2px solid currentColor;
  border-radius: 2px;
  background-color: transparent;
  pointer-events: none;
  will-change: background-color, border-color;
  transition: background-color 90ms cubic-bezier(0.4, 0, 0.6, 1), border-color 90ms cubic-bezier(0.4, 0, 0.6, 1);
  -webkit-print-color-adjust: exact;
  color-adjust: exact;
  border-color: var(--mat-checkbox-unselected-icon-color, var(--mat-sys-on-surface-variant));
  top: calc((var(--mat-checkbox-state-layer-size, 40px) - 18px) / 2);
  left: calc((var(--mat-checkbox-state-layer-size, 40px) - 18px) / 2);
}

.mdc-checkbox__native-control:enabled:checked ~ .mdc-checkbox__background,
.mdc-checkbox__native-control:enabled:indeterminate ~ .mdc-checkbox__background {
  border-color: var(--mat-checkbox-selected-icon-color, var(--mat-sys-primary));
  background-color: var(--mat-checkbox-selected-icon-color, var(--mat-sys-primary));
}

.mdc-checkbox--disabled .mdc-checkbox__background {
  border-color: var(--mat-checkbox-disabled-unselected-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
@media (forced-colors: active) {
  .mdc-checkbox--disabled .mdc-checkbox__background {
    border-color: GrayText;
  }
}

.mdc-checkbox__native-control:disabled:checked ~ .mdc-checkbox__background,
.mdc-checkbox__native-control:disabled:indeterminate ~ .mdc-checkbox__background {
  background-color: var(--mat-checkbox-disabled-selected-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
  border-color: transparent;
}
@media (forced-colors: active) {
  .mdc-checkbox__native-control:disabled:checked ~ .mdc-checkbox__background,
  .mdc-checkbox__native-control:disabled:indeterminate ~ .mdc-checkbox__background {
    border-color: GrayText;
  }
}

.mdc-checkbox:hover > .mdc-checkbox__native-control:not(:checked) ~ .mdc-checkbox__background,
.mdc-checkbox:hover > .mdc-checkbox__native-control:not(:indeterminate) ~ .mdc-checkbox__background {
  border-color: var(--mat-checkbox-unselected-hover-icon-color, var(--mat-sys-on-surface));
  background-color: transparent;
}

.mdc-checkbox:hover > .mdc-checkbox__native-control:checked ~ .mdc-checkbox__background,
.mdc-checkbox:hover > .mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background {
  border-color: var(--mat-checkbox-selected-hover-icon-color, var(--mat-sys-primary));
  background-color: var(--mat-checkbox-selected-hover-icon-color, var(--mat-sys-primary));
}

.mdc-checkbox__native-control:focus:focus:not(:checked) ~ .mdc-checkbox__background,
.mdc-checkbox__native-control:focus:focus:not(:indeterminate) ~ .mdc-checkbox__background {
  border-color: var(--mat-checkbox-unselected-focus-icon-color, var(--mat-sys-on-surface));
}

.mdc-checkbox__native-control:focus:focus:checked ~ .mdc-checkbox__background,
.mdc-checkbox__native-control:focus:focus:indeterminate ~ .mdc-checkbox__background {
  border-color: var(--mat-checkbox-selected-focus-icon-color, var(--mat-sys-primary));
  background-color: var(--mat-checkbox-selected-focus-icon-color, var(--mat-sys-primary));
}

.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox:hover > .mdc-checkbox__native-control ~ .mdc-checkbox__background,
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox .mdc-checkbox__native-control:focus ~ .mdc-checkbox__background,
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__background {
  border-color: var(--mat-checkbox-disabled-unselected-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
@media (forced-colors: active) {
  .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox:hover > .mdc-checkbox__native-control ~ .mdc-checkbox__background,
  .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox .mdc-checkbox__native-control:focus ~ .mdc-checkbox__background,
  .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__background {
    border-color: GrayText;
  }
}
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__native-control:checked ~ .mdc-checkbox__background,
.mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background {
  background-color: var(--mat-checkbox-disabled-selected-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
  border-color: transparent;
}

.mdc-checkbox__checkmark {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  width: 100%;
  opacity: 0;
  transition: opacity 180ms cubic-bezier(0.4, 0, 0.6, 1);
  color: var(--mat-checkbox-selected-checkmark-color, var(--mat-sys-on-primary));
}
@media (forced-colors: active) {
  .mdc-checkbox__checkmark {
    color: CanvasText;
  }
}

.mdc-checkbox--disabled .mdc-checkbox__checkmark, .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__checkmark {
  color: var(--mat-checkbox-disabled-selected-checkmark-color, var(--mat-sys-surface));
}
@media (forced-colors: active) {
  .mdc-checkbox--disabled .mdc-checkbox__checkmark, .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__checkmark {
    color: GrayText;
  }
}

.mdc-checkbox__checkmark-path {
  transition: stroke-dashoffset 180ms cubic-bezier(0.4, 0, 0.6, 1);
  stroke: currentColor;
  stroke-width: 3.12px;
  stroke-dashoffset: 29.7833385;
  stroke-dasharray: 29.7833385;
}

.mdc-checkbox__mixedmark {
  width: 100%;
  height: 0;
  transform: scaleX(0) rotate(0deg);
  border-width: 1px;
  border-style: solid;
  opacity: 0;
  transition: opacity 90ms cubic-bezier(0.4, 0, 0.6, 1), transform 90ms cubic-bezier(0.4, 0, 0.6, 1);
  border-color: var(--mat-checkbox-selected-checkmark-color, var(--mat-sys-on-primary));
}
@media (forced-colors: active) {
  .mdc-checkbox__mixedmark {
    margin: 0 1px;
  }
}

.mdc-checkbox--disabled .mdc-checkbox__mixedmark, .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__mixedmark {
  border-color: var(--mat-checkbox-disabled-selected-checkmark-color, var(--mat-sys-surface));
}
@media (forced-colors: active) {
  .mdc-checkbox--disabled .mdc-checkbox__mixedmark, .mdc-checkbox--disabled.mat-mdc-checkbox-disabled-interactive .mdc-checkbox__mixedmark {
    border-color: GrayText;
  }
}

.mdc-checkbox--anim-unchecked-checked .mdc-checkbox__background,
.mdc-checkbox--anim-unchecked-indeterminate .mdc-checkbox__background,
.mdc-checkbox--anim-checked-unchecked .mdc-checkbox__background,
.mdc-checkbox--anim-indeterminate-unchecked .mdc-checkbox__background {
  animation-duration: 180ms;
  animation-timing-function: linear;
}

.mdc-checkbox--anim-unchecked-checked .mdc-checkbox__checkmark-path {
  animation: mdc-checkbox-unchecked-checked-checkmark-path 180ms linear;
  transition: none;
}

.mdc-checkbox--anim-unchecked-indeterminate .mdc-checkbox__mixedmark {
  animation: mdc-checkbox-unchecked-indeterminate-mixedmark 90ms linear;
  transition: none;
}

.mdc-checkbox--anim-checked-unchecked .mdc-checkbox__checkmark-path {
  animation: mdc-checkbox-checked-unchecked-checkmark-path 90ms linear;
  transition: none;
}

.mdc-checkbox--anim-checked-indeterminate .mdc-checkbox__checkmark {
  animation: mdc-checkbox-checked-indeterminate-checkmark 90ms linear;
  transition: none;
}
.mdc-checkbox--anim-checked-indeterminate .mdc-checkbox__mixedmark {
  animation: mdc-checkbox-checked-indeterminate-mixedmark 90ms linear;
  transition: none;
}

.mdc-checkbox--anim-indeterminate-checked .mdc-checkbox__checkmark {
  animation: mdc-checkbox-indeterminate-checked-checkmark 500ms linear;
  transition: none;
}
.mdc-checkbox--anim-indeterminate-checked .mdc-checkbox__mixedmark {
  animation: mdc-checkbox-indeterminate-checked-mixedmark 500ms linear;
  transition: none;
}

.mdc-checkbox--anim-indeterminate-unchecked .mdc-checkbox__mixedmark {
  animation: mdc-checkbox-indeterminate-unchecked-mixedmark 300ms linear;
  transition: none;
}

.mdc-checkbox__native-control:checked ~ .mdc-checkbox__background,
.mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background {
  transition: border-color 90ms cubic-bezier(0, 0, 0.2, 1), background-color 90ms cubic-bezier(0, 0, 0.2, 1);
}
.mdc-checkbox__native-control:checked ~ .mdc-checkbox__background > .mdc-checkbox__checkmark > .mdc-checkbox__checkmark-path,
.mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background > .mdc-checkbox__checkmark > .mdc-checkbox__checkmark-path {
  stroke-dashoffset: 0;
}

.mdc-checkbox__native-control:checked ~ .mdc-checkbox__background > .mdc-checkbox__checkmark {
  transition: opacity 180ms cubic-bezier(0, 0, 0.2, 1), transform 180ms cubic-bezier(0, 0, 0.2, 1);
  opacity: 1;
}
.mdc-checkbox__native-control:checked ~ .mdc-checkbox__background > .mdc-checkbox__mixedmark {
  transform: scaleX(1) rotate(-45deg);
}

.mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background > .mdc-checkbox__checkmark {
  transform: rotate(45deg);
  opacity: 0;
  transition: opacity 90ms cubic-bezier(0.4, 0, 0.6, 1), transform 90ms cubic-bezier(0.4, 0, 0.6, 1);
}
.mdc-checkbox__native-control:indeterminate ~ .mdc-checkbox__background > .mdc-checkbox__mixedmark {
  transform: scaleX(1) rotate(0deg);
  opacity: 1;
}

@keyframes mdc-checkbox-unchecked-checked-checkmark-path {
  0%, 50% {
    stroke-dashoffset: 29.7833385;
  }
  50% {
    animation-timing-function: cubic-bezier(0, 0, 0.2, 1);
  }
  100% {
    stroke-dashoffset: 0;
  }
}
@keyframes mdc-checkbox-unchecked-indeterminate-mixedmark {
  0%, 68.2% {
    transform: scaleX(0);
  }
  68.2% {
    animation-timing-function: cubic-bezier(0, 0, 0, 1);
  }
  100% {
    transform: scaleX(1);
  }
}
@keyframes mdc-checkbox-checked-unchecked-checkmark-path {
  from {
    animation-timing-function: cubic-bezier(0.4, 0, 1, 1);
    opacity: 1;
    stroke-dashoffset: 0;
  }
  to {
    opacity: 0;
    stroke-dashoffset: -29.7833385;
  }
}
@keyframes mdc-checkbox-checked-indeterminate-checkmark {
  from {
    animation-timing-function: cubic-bezier(0, 0, 0.2, 1);
    transform: rotate(0deg);
    opacity: 1;
  }
  to {
    transform: rotate(45deg);
    opacity: 0;
  }
}
@keyframes mdc-checkbox-indeterminate-checked-checkmark {
  from {
    animation-timing-function: cubic-bezier(0.14, 0, 0, 1);
    transform: rotate(45deg);
    opacity: 0;
  }
  to {
    transform: rotate(360deg);
    opacity: 1;
  }
}
@keyframes mdc-checkbox-checked-indeterminate-mixedmark {
  from {
    animation-timing-function: cubic-bezier(0, 0, 0.2, 1);
    transform: rotate(-45deg);
    opacity: 0;
  }
  to {
    transform: rotate(0deg);
    opacity: 1;
  }
}
@keyframes mdc-checkbox-indeterminate-checked-mixedmark {
  from {
    animation-timing-function: cubic-bezier(0.14, 0, 0, 1);
    transform: rotate(0deg);
    opacity: 1;
  }
  to {
    transform: rotate(315deg);
    opacity: 0;
  }
}
@keyframes mdc-checkbox-indeterminate-unchecked-mixedmark {
  0% {
    animation-timing-function: linear;
    transform: scaleX(1);
    opacity: 1;
  }
  32.8%, 100% {
    transform: scaleX(0);
    opacity: 0;
  }
}
.mat-mdc-checkbox {
  display: inline-block;
  position: relative;
  -webkit-tap-highlight-color: transparent;
}
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mat-mdc-checkbox-touch-target,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__native-control,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__ripple,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mat-mdc-checkbox-ripple::before,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__background,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__background > .mdc-checkbox__checkmark,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__background > .mdc-checkbox__checkmark > .mdc-checkbox__checkmark-path,
.mat-mdc-checkbox._mat-animation-noopable > .mat-internal-form-field > .mdc-checkbox > .mdc-checkbox__background > .mdc-checkbox__mixedmark {
  transition: none !important;
  animation: none !important;
}
.mat-mdc-checkbox label {
  cursor: pointer;
}
.mat-mdc-checkbox .mat-internal-form-field {
  color: var(--mat-checkbox-label-text-color, var(--mat-sys-on-surface));
  font-family: var(--mat-checkbox-label-text-font, var(--mat-sys-body-medium-font));
  line-height: var(--mat-checkbox-label-text-line-height, var(--mat-sys-body-medium-line-height));
  font-size: var(--mat-checkbox-label-text-size, var(--mat-sys-body-medium-size));
  letter-spacing: var(--mat-checkbox-label-text-tracking, var(--mat-sys-body-medium-tracking));
  font-weight: var(--mat-checkbox-label-text-weight, var(--mat-sys-body-medium-weight));
}
.mat-mdc-checkbox.mat-mdc-checkbox-disabled.mat-mdc-checkbox-disabled-interactive {
  pointer-events: auto;
}
.mat-mdc-checkbox.mat-mdc-checkbox-disabled.mat-mdc-checkbox-disabled-interactive input {
  cursor: default;
}
.mat-mdc-checkbox.mat-mdc-checkbox-disabled label {
  cursor: default;
  color: var(--mat-checkbox-disabled-label-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
@media (forced-colors: active) {
  .mat-mdc-checkbox.mat-mdc-checkbox-disabled label {
    color: GrayText;
  }
}
.mat-mdc-checkbox label:empty {
  display: none;
}
.mat-mdc-checkbox .mdc-checkbox__ripple {
  opacity: 0;
}

.mat-mdc-checkbox .mat-mdc-checkbox-ripple,
.mdc-checkbox__ripple {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  border-radius: 50%;
  pointer-events: none;
}
.mat-mdc-checkbox .mat-mdc-checkbox-ripple:not(:empty),
.mdc-checkbox__ripple:not(:empty) {
  transform: translateZ(0);
}

.mat-mdc-checkbox-ripple .mat-ripple-element {
  opacity: 0.1;
}

.mat-mdc-checkbox-touch-target {
  position: absolute;
  top: 50%;
  left: 50%;
  height: var(--mat-checkbox-touch-target-size, 48px);
  width: var(--mat-checkbox-touch-target-size, 48px);
  transform: translate(-50%, -50%);
  display: var(--mat-checkbox-touch-target-display, block);
}

.mat-mdc-checkbox .mat-mdc-checkbox-ripple::before {
  border-radius: 50%;
}

.mdc-checkbox__native-control:focus-visible ~ .mat-focus-indicator::before {
  content: "";
}
`],encapsulation:2,changeDetection:0})}return t})(),wt=(()=>{class t{static \u0275fac=function(c){return new(c||t)};static \u0275mod=F({type:t});static \u0275inj=z({imports:[Ft,at]})}return t})();function Lt(t,i){t&1&&p(0,"mat-progress-bar",8)}function Vt(t,i){if(t&1&&(a(0,"div",9)(1,"mat-card",10)(2,"mat-card-content")(3,"mat-icon",11),o(4,"currency_rupee"),n(),a(5,"div",12),o(6),R(7,"number"),n(),a(8,"div",13),o(9,"Total Revenue"),n()()(),a(10,"mat-card",10)(11,"mat-card-content")(12,"mat-icon",11),o(13,"people"),n(),a(14,"div",12),o(15),n(),a(16,"div",13),o(17,"Monthly Active Users"),n()()(),a(18,"mat-card",10)(19,"mat-card-content")(20,"mat-icon",11),o(21,"school"),n(),a(22,"div",12),o(23),n(),a(24,"div",13),o(25,"Total Enrollments"),n()()(),a(26,"mat-card",10)(27,"mat-card-content")(28,"mat-icon",11),o(29,"menu_book"),n(),a(30,"div",12),o(31),n(),a(32,"div",13),o(33,"Published Courses"),n()()()()),t&2){let e=b();m(6),y("\u20B9",Le(7,4,e.stats.totalRevenue)),m(9),_(e.stats.monthlyActiveUsers),m(8),_(e.stats.totalEnrollments),m(8),_(e.stats.publishedCourses)}}var ce=class t{constructor(i){this.http=i}stats={totalRevenue:0,monthlyActiveUsers:0,totalEnrollments:0,publishedCourses:0};isLoading=!0;ngOnInit(){this.http.get(`${k.apiUrl}/payments/admin/stats`).subscribe({next:i=>{this.stats=de(de({},this.stats),i),this.isLoading=!1},error:()=>{this.isLoading=!1}})}static \u0275fac=function(e){return new(e||t)(v(S))};static \u0275cmp=f({type:t,selectors:[["app-platform-analytics"]],standalone:!1,decls:19,vars:2,consts:[[1,"analytics-page"],[1,"page-header"],["mode","indeterminate",4,"ngIf"],["class","kpi-grid",4,"ngIf"],[1,"quick-links"],["mat-raised-button","","color","primary","routerLink","/admin/users"],["mat-raised-button","","routerLink","/admin/approvals"],["mat-stroked-button","","routerLink","/admin/notifications"],["mode","indeterminate"],[1,"kpi-grid"],[1,"kpi-card"],[1,"kpi-icon"],[1,"kpi-value"],[1,"kpi-label"]],template:function(e,c){e&1&&(a(0,"div",0)(1,"div",1)(2,"h1"),o(3,"Platform Analytics"),n()(),d(4,Lt,1,0,"mat-progress-bar",2)(5,Vt,34,6,"div",3),a(6,"div",4)(7,"a",5)(8,"mat-icon"),o(9,"manage_accounts"),n(),o(10," Manage Users "),n(),a(11,"a",6)(12,"mat-icon"),o(13,"approval"),n(),o(14," Course Approvals "),n(),a(15,"a",7)(16,"mat-icon"),o(17,"notifications"),n(),o(18," Send Notification "),n()()()),e&2&&(m(4),l("ngIf",c.isLoading),m(),l("ngIf",!c.isLoading))},dependencies:[I,Ze,A,V,H,E,P,Ge],styles:[".analytics-page[_ngcontent-%COMP%]{padding:40px;max-width:1200px;margin:0 auto}.page-header[_ngcontent-%COMP%]{margin-bottom:32px}.page-header[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%]{font-size:2rem;color:#1e3a5f;margin:0}.kpi-grid[_ngcontent-%COMP%]{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:24px;margin-bottom:40px}.kpi-card[_ngcontent-%COMP%]{text-align:center;padding:16px;border-top:4px solid #2E75B6}.kpi-icon[_ngcontent-%COMP%]{font-size:2.5rem;color:#2e75b6;margin-bottom:8px}.kpi-value[_ngcontent-%COMP%]{font-size:2rem;font-weight:700;color:#1e3a5f;margin-bottom:4px}.kpi-label[_ngcontent-%COMP%]{color:#666;font-size:.9rem}.quick-links[_ngcontent-%COMP%]{display:flex;gap:16px;flex-wrap:wrap}"]})};function qt(t,i){t&1&&p(0,"mat-progress-bar",13)}function Gt(t,i){t&1&&(a(0,"mat-header-cell"),o(1,"Name"),n())}function Xt(t,i){if(t&1&&(a(0,"mat-cell"),o(1),n()),t&2){let e=i.$implicit;m(),_(e.fullName)}}function Qt(t,i){t&1&&(a(0,"mat-header-cell"),o(1,"Email"),n())}function Zt(t,i){if(t&1&&(a(0,"mat-cell"),o(1),n()),t&2){let e=i.$implicit;m(),_(e.email)}}function Kt(t,i){t&1&&(a(0,"mat-header-cell"),o(1,"Role"),n())}function Jt(t,i){if(t&1&&(a(0,"mat-cell")(1,"mat-chip"),o(2),n()()),t&2){let e=i.$implicit;m(2),_(e.role)}}function Wt(t,i){t&1&&(a(0,"mat-header-cell"),o(1,"Status"),n())}function Yt(t,i){if(t&1&&(a(0,"mat-cell")(1,"mat-chip",24),o(2),n()()),t&2){let e=i.$implicit;m(),l("color",e.isActive?"accent":"warn"),m(),y(" ",e.isActive?"Active":"Suspended"," ")}}function en(t,i){t&1&&(a(0,"mat-header-cell"),o(1,"Actions"),n())}function tn(t,i){if(t&1){let e=D();a(0,"button",28),u("click",function(){w(e);let r=b().$implicit,s=b(2);return T(s.suspend(r.id))}),a(1,"mat-icon"),o(2,"block"),n()()}}function nn(t,i){if(t&1){let e=D();a(0,"button",29),u("click",function(){w(e);let r=b().$implicit,s=b(2);return T(s.unsuspend(r.id))}),a(1,"mat-icon"),o(2,"check_circle"),n()()}}function an(t,i){if(t&1){let e=D();a(0,"mat-cell"),d(1,tn,3,0,"button",25)(2,nn,3,0,"button",26),a(3,"button",27),u("click",function(){let r=w(e).$implicit,s=b(2);return T(s.delete(r.id))}),a(4,"mat-icon"),o(5,"delete"),n()()()}if(t&2){let e=i.$implicit;m(),l("ngIf",e.isActive),m(),l("ngIf",!e.isActive)}}function on(t,i){t&1&&p(0,"mat-header-row")}function cn(t,i){t&1&&p(0,"mat-row")}function rn(t,i){if(t&1&&(a(0,"mat-table",14),x(1,15),d(2,Gt,2,0,"mat-header-cell",16)(3,Xt,2,1,"mat-cell",17),g(),x(4,18),d(5,Qt,2,0,"mat-header-cell",16)(6,Zt,2,1,"mat-cell",17),g(),x(7,19),d(8,Kt,2,0,"mat-header-cell",16)(9,Jt,3,1,"mat-cell",17),g(),x(10,20),d(11,Wt,2,0,"mat-header-cell",16)(12,Yt,3,2,"mat-cell",17),g(),x(13,21),d(14,en,2,0,"mat-header-cell",16)(15,an,6,2,"mat-cell",17),g(),d(16,on,1,0,"mat-header-row",22)(17,cn,1,0,"mat-row",23),n()),t&2){let e=b();l("dataSource",e.users),m(16),l("matHeaderRowDef",e.displayedColumns),m(),l("matRowDefColumns",e.displayedColumns)}}var re=class t{constructor(i){this.http=i}users=[];isLoading=!0;searchControl=new _e("");roleControl=new _e("");displayedColumns=["name","email","role","status","actions"];ngOnInit(){this.loadUsers(),this.searchControl.valueChanges.pipe(Me(300),Ie()).subscribe(()=>this.loadUsers()),this.roleControl.valueChanges.subscribe(()=>this.loadUsers())}loadUsers(){let i=`${k.apiUrl}/auth/users?`;this.searchControl.value&&(i+=`q=${this.searchControl.value}&`),this.roleControl.value&&(i+=`role=${this.roleControl.value}`),this.http.get(i).subscribe({next:e=>{this.users=e,this.isLoading=!1},error:()=>{this.isLoading=!1}})}suspend(i){this.http.put(`${k.apiUrl}/admin/users/${i}/suspend`,{}).subscribe({next:()=>this.loadUsers()})}unsuspend(i){this.http.put(`${k.apiUrl}/admin/users/${i}/unsuspend`,{}).subscribe({next:()=>this.loadUsers()})}delete(i){confirm("Are you sure you want to delete this user?")&&this.http.delete(`${k.apiUrl}/admin/users/${i}`).subscribe({next:()=>this.loadUsers()})}static \u0275fac=function(e){return new(e||t)(v(S))};static \u0275cmp=f({type:t,selectors:[["app-user-management"]],standalone:!1,decls:25,vars:4,consts:[[1,"users-page"],[1,"page-header"],[1,"filters"],["appearance","outline"],["matInput","","placeholder","Name or email",3,"formControl"],["matSuffix",""],[3,"formControl"],["value",""],["value","Student"],["value","Instructor"],["value","Admin"],["mode","indeterminate",4,"ngIf"],["class","users-table",3,"dataSource",4,"ngIf"],["mode","indeterminate"],[1,"users-table",3,"dataSource"],["matColumnDef","name"],[4,"matHeaderCellDef"],[4,"matCellDef"],["matColumnDef","email"],["matColumnDef","role"],["matColumnDef","status"],["matColumnDef","actions"],[4,"matHeaderRowDef"],[4,"matRowDef","matRowDefColumns"],["selected","",3,"color"],["mat-icon-button","","matTooltip","Suspend",3,"click",4,"ngIf"],["mat-icon-button","","matTooltip","Unsuspend","color","accent",3,"click",4,"ngIf"],["mat-icon-button","","color","warn","matTooltip","Delete",3,"click"],["mat-icon-button","","matTooltip","Suspend",3,"click"],["mat-icon-button","","matTooltip","Unsuspend","color","accent",3,"click"]],template:function(e,c){e&1&&(a(0,"div",0)(1,"div",1)(2,"h1"),o(3,"User Management"),n()(),a(4,"div",2)(5,"mat-form-field",3)(6,"mat-label"),o(7,"Search users"),n(),p(8,"input",4),a(9,"mat-icon",5),o(10,"search"),n()(),a(11,"mat-form-field",3)(12,"mat-label"),o(13,"Filter by role"),n(),a(14,"mat-select",6)(15,"mat-option",7),o(16,"All Roles"),n(),a(17,"mat-option",8),o(18,"Student"),n(),a(19,"mat-option",9),o(20,"Instructor"),n(),a(21,"mat-option",10),o(22,"Admin"),n()()()(),d(23,qt,1,0,"mat-progress-bar",11)(24,rn,18,3,"mat-table",12),n()),e&2&&(m(8),l("formControl",c.searchControl),m(6),l("formControl",c.roleControl),m(9),l("ngIf",c.isLoading),m(),l("ngIf",!c.isLoading))},dependencies:[I,B,j,pt,nt,X,G,q,kt,E,Z,Q,K,W,ne,Y,J,ae,ee,te,ie,oe,vt,P],styles:[".users-page[_ngcontent-%COMP%]{padding:40px;max-width:1200px;margin:0 auto}.page-header[_ngcontent-%COMP%]{margin-bottom:24px}.page-header[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%]{font-size:2rem;color:#1e3a5f;margin:0}.filters[_ngcontent-%COMP%]{display:flex;gap:16px;margin-bottom:24px}.users-table[_ngcontent-%COMP%]{width:100%}"]})};function mn(t,i){t&1&&p(0,"mat-progress-bar",5)}function ln(t,i){t&1&&(a(0,"mat-header-cell"),o(1,"Course Title"),n())}function sn(t,i){if(t&1&&(a(0,"mat-cell"),o(1),n()),t&2){let e=i.$implicit;m(),_(e.title)}}function dn(t,i){t&1&&(a(0,"mat-header-cell"),o(1,"Instructor"),n())}function pn(t,i){if(t&1&&(a(0,"mat-cell"),o(1),R(2,"slice"),n()),t&2){let e=i.$implicit;m(),y("",He(2,1,e.instructorId,0,8),"...")}}function hn(t,i){t&1&&(a(0,"mat-header-cell"),o(1,"Submitted"),n())}function bn(t,i){if(t&1&&(a(0,"mat-cell"),o(1),R(2,"date"),n()),t&2){let e=i.$implicit;m(),_(Ve(2,1,e.createdAt,"mediumDate"))}}function un(t,i){t&1&&(a(0,"mat-header-cell"),o(1,"Actions"),n())}function _n(t,i){if(t&1){let e=D();a(0,"mat-cell")(1,"button",15),u("click",function(){let r=w(e).$implicit,s=b(2);return T(s.approve(r.id))}),a(2,"mat-icon"),o(3,"check"),n(),o(4," Approve "),n(),a(5,"button",16),u("click",function(){let r=w(e).$implicit,s=b(2);return T(s.reject(r.id))}),a(6,"mat-icon"),o(7,"close"),n(),o(8," Reject "),n()()}}function kn(t,i){t&1&&p(0,"mat-header-row")}function fn(t,i){t&1&&p(0,"mat-row")}function xn(t,i){if(t&1&&(a(0,"mat-table",6),x(1,7),d(2,ln,2,0,"mat-header-cell",8)(3,sn,2,1,"mat-cell",9),g(),x(4,10),d(5,dn,2,0,"mat-header-cell",8)(6,pn,3,5,"mat-cell",9),g(),x(7,11),d(8,hn,2,0,"mat-header-cell",8)(9,bn,3,4,"mat-cell",9),g(),x(10,12),d(11,un,2,0,"mat-header-cell",8)(12,_n,9,0,"mat-cell",9),g(),d(13,kn,1,0,"mat-header-row",13)(14,fn,1,0,"mat-row",14),n()),t&2){let e=b();l("dataSource",e.courses),m(13),l("matHeaderRowDef",e.displayedColumns),m(),l("matRowDefColumns",e.displayedColumns)}}function gn(t,i){t&1&&(a(0,"div",17)(1,"mat-icon"),o(2,"approval"),n(),a(3,"p"),o(4,"No courses pending approval."),n()())}var me=class t{constructor(i){this.http=i}courses=[];isLoading=!0;displayedColumns=["title","instructor","submitted","actions"];ngOnInit(){this.loadCourses()}loadCourses(){this.http.get(`${k.apiUrl}/courses?state=PendingApproval`).subscribe({next:i=>{this.courses=i.items||[],this.isLoading=!1},error:()=>{this.isLoading=!1}})}approve(i){this.http.put(`${k.apiUrl}/admin/courses/${i}/approve`,{}).subscribe({next:()=>this.loadCourses()})}reject(i){let e=prompt("Enter rejection reason:");e&&this.http.put(`${k.apiUrl}/admin/courses/${i}/reject`,{reason:e}).subscribe({next:()=>this.loadCourses()})}static \u0275fac=function(e){return new(e||t)(v(S))};static \u0275cmp=f({type:t,selectors:[["app-course-approvals"]],standalone:!1,decls:9,vars:4,consts:[[1,"approvals-page"],[1,"page-header"],["mode","indeterminate",4,"ngIf"],["class","approvals-table",3,"dataSource",4,"ngIf"],["class","empty-state",4,"ngIf"],["mode","indeterminate"],[1,"approvals-table",3,"dataSource"],["matColumnDef","title"],[4,"matHeaderCellDef"],[4,"matCellDef"],["matColumnDef","instructor"],["matColumnDef","submitted"],["matColumnDef","actions"],[4,"matHeaderRowDef"],[4,"matRowDef","matRowDefColumns"],["mat-raised-button","","color","accent",2,"margin-right","8px",3,"click"],["mat-stroked-button","","color","warn",3,"click"],[1,"empty-state"]],template:function(e,c){e&1&&(a(0,"div",0)(1,"div",1)(2,"h1"),o(3,"Course Approval Queue"),n(),a(4,"p"),o(5),n()(),d(6,mn,1,0,"mat-progress-bar",2)(7,xn,15,3,"mat-table",3)(8,gn,5,0,"div",4),n()),e&2&&(m(5),y("",c.courses.length," courses pending review"),m(),l("ngIf",c.isLoading),m(),l("ngIf",!c.isLoading),m(),l("ngIf",!c.isLoading&&c.courses.length===0))},dependencies:[I,A,E,K,W,ne,Y,J,ae,ee,te,ie,oe,P,Xe,qe],styles:[".approvals-page[_ngcontent-%COMP%]{padding:40px;max-width:1100px;margin:0 auto}.page-header[_ngcontent-%COMP%]{margin-bottom:32px}.page-header[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%]{font-size:2rem;color:#1e3a5f;margin:0}.page-header[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#666}.approvals-table[_ngcontent-%COMP%]{width:100%}.empty-state[_ngcontent-%COMP%]{text-align:center;padding:60px;color:#666}.empty-state[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{font-size:4rem;opacity:.3;margin-bottom:16px}"]})};function vn(t,i){if(t&1&&(a(0,"div",15),o(1),n()),t&2){let e=b();m(),_(e.successMessage)}}var le=class t{constructor(i,e){this.fb=i;this.http=e;this.form=this.fb.group({title:["",$.required],body:["",$.required],targetRole:["All",$.required]})}form;isSubmitting=!1;successMessage="";onSubmit(){this.form.invalid||(this.isSubmitting=!0,this.http.post(`${k.apiUrl}/notifications/broadcast`,this.form.value).subscribe({next:()=>{this.isSubmitting=!1,this.successMessage="Notification sent successfully!",this.form.reset({targetRole:"All"}),setTimeout(()=>this.successMessage="",3e3)},error:()=>{this.isSubmitting=!1}}))}static \u0275fac=function(e){return new(e||t)(v(ut),v(S))};static \u0275cmp=f({type:t,selectors:[["app-system-notifications"]],standalone:!1,decls:36,vars:4,consts:[[1,"notifications-page"],[1,"page-header"],[1,"compose-card"],["class","success-message",4,"ngIf"],[3,"ngSubmit","formGroup"],["appearance","outline",1,"full-width"],["matInput","","formControlName","title"],["matInput","","formControlName","body","rows","5"],["appearance","outline"],["formControlName","targetRole"],["value","All"],["value","Student"],["value","Instructor"],[1,"form-actions"],["mat-raised-button","","color","primary","type","submit",3,"disabled"],[1,"success-message"]],template:function(e,c){e&1&&(a(0,"div",0)(1,"div",1)(2,"h1"),o(3,"System Notifications"),n(),a(4,"p"),o(5,"Broadcast messages to users by role"),n()(),a(6,"mat-card",2)(7,"mat-card-header")(8,"mat-card-title"),o(9,"Compose Broadcast"),n()(),a(10,"mat-card-content"),d(11,vn,2,1,"div",3),a(12,"form",4),u("ngSubmit",function(){return c.onSubmit()}),a(13,"mat-form-field",5)(14,"mat-label"),o(15,"Title"),n(),p(16,"input",6),n(),a(17,"mat-form-field",5)(18,"mat-label"),o(19,"Message"),n(),p(20,"textarea",7),n(),a(21,"mat-form-field",8)(22,"mat-label"),o(23,"Target Audience"),n(),a(24,"mat-select",9)(25,"mat-option",10),o(26,"All Users"),n(),a(27,"mat-option",11),o(28,"Students Only"),n(),a(29,"mat-option",12),o(30,"Instructors Only"),n()()(),a(31,"div",13)(32,"button",14)(33,"mat-icon"),o(34,"send"),n(),o(35),n()()()()()()),e&2&&(m(11),l("ngIf",c.successMessage),m(),l("formGroup",c.form),m(20),l("disabled",c.isSubmitting||c.form.invalid),m(3),y(" ",c.isSubmitting?"Sending...":"Send Notification"," "))},dependencies:[I,dt,B,j,st,bt,ht,A,V,H,ct,ot,X,G,q,E,Z,Q],styles:[".notifications-page[_ngcontent-%COMP%]{padding:40px;max-width:700px;margin:0 auto}.page-header[_ngcontent-%COMP%]{margin-bottom:32px}.page-header[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%]{font-size:2rem;color:#1e3a5f;margin:0}.page-header[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{color:#666;margin:4px 0 0}.compose-card[_ngcontent-%COMP%]{padding:8px}.full-width[_ngcontent-%COMP%]{width:100%;margin-bottom:16px}.form-actions[_ngcontent-%COMP%]{display:flex;justify-content:flex-end;margin-top:16px}.success-message[_ngcontent-%COMP%]{background:#d4edda;color:#155724;padding:12px 16px;border-radius:4px;margin-bottom:16px}"]})};var yn=[{path:"analytics",component:ce},{path:"users",component:re},{path:"approvals",component:me},{path:"notifications",component:le},{path:"",redirectTo:"analytics",pathMatch:"full"}],Dt=class t{static \u0275fac=function(e){return new(e||t)};static \u0275mod=F({type:t});static \u0275inj=z({imports:[Qe,_t,Ke.forChild(yn),it,rt,ft,Ct,xt,St,yt,Mt,gt,wt,It]})};export{Dt as AdminModule};
